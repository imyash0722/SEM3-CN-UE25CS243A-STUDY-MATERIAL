# Project 25: Network Intrusion Detection and Response

A clean, direct implementation of an SDN-based Intrusion Detection and Dynamic Response System for Mininet and Ryu (OpenFlow 1.3).

---

## What Each File Does

| File | Lines | Purpose |
|---|---|---|
| [`server.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/server.py) | ~40 | Multi-threaded TCP socket server running the protected service on port 8080 |
| [`client.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/client.py) | ~35 | Legitimate client making normal TCP requests and measuring latency |
| [`attacker.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/attacker.py) | ~50 | Security-test traffic generator: port scanning (`scan`) and connection flood (`flood`) |
| [`controller.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/controller.py) | ~115 | Ryu OpenFlow 1.3 controller: tracks connection rates & ports, dynamically installs DROP rules |
| [`topology.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/topology.py) | ~40 | Mininet topology: 3 hosts (`h1` client, `h2` attacker, `h3` server) + 1 switch (`s1`) |

---

## How to Run in Mininet

### 1. Start the Ryu Controller
```bash
ryu-manager controller.py --verbose
```

### 2. Start the Mininet Network (in another terminal)
```bash
sudo python3 topology.py
```

### 3. In the Mininet CLI:
```bash
# Start protected service on server h3
mininet> h3 python3 server.py &

# Send legitimate request from client h1 (succeeds with ~1ms latency)
mininet> h1 python3 client.py 10.0.0.3

# Launch port scan attack from h2
mininet> h2 python3 attacker.py scan 10.0.0.3
```

### 4. What Happens:
1. `h2` scans ports 21, 22, 23, 25, 80...
2. `controller.py` notices `h2` has accessed $\ge 5$ distinct ports.
3. The controller installs a **Priority 200 DROP flow rule** on switch `s1` matching `ipv4_src = 10.0.0.2`.
4. All further packets from `h2` are dropped immediately in hardware at the switch!
5. Legitimate client `h1` continues communicating with server `h3` completely unaffected.

You can verify the active DROP rule on the switch:
```bash
mininet> sh ovs-ofctl dump-flows s1 -O OpenFlow13
```

---

## Advanced Tools & Test Suites
If your evaluator or viva requires formal comparative evaluation tables, automated test suites, or multi-switch topologies, see the [`advanced/`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/advanced) directory:
* [`demo.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/advanced/demo.py): 5-phase interactive terminal showcase
* [`test_suite.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/advanced/test_suite.py): Automated 6-test verification suite
* [`analyze_results.py`](file:///mnt/shared/sem3/CN/project/network_intrusion_detection/advanced/analyze_results.py): Baseline vs. Defense comparative benchmark
