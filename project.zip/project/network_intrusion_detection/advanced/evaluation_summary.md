# Project 25 — Comparative Evaluation Summary

| Performance Metric | Baseline (Static / No Defense) | SDN Dynamic Defense |
|---|---|---|
| Adversary Attack Attempts | 50 | 50 |
| Attack Infiltrations Landed | 50 | 5 |
| Adversary Traffic Blocked (%) | 0.0% | 90.0% |
| Legitimate Client Success Rate | 100.0% | 100.0% |
| Legitimate Client Latency (RTT) | 0.66 ms | 0.66 ms |
| Intrusion Detection Time | N/A (Disabled) | 124.50 ms |
| SDN FlowMod Response Time | N/A (Disabled) | 8.20 ms |
