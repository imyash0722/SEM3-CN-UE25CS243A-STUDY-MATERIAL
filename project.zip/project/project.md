# Project 25: Network Intrusion Detection and Response
Develop an intrusion-detection prototype that analyzes TCP socket traffic, identifies predefined abnormal behaviors and dynamically responds by modifying SDN forwarding rules.
- Generate controlled TCP security-test traffic
- Monitor connection rates
- Collect flow statistics
- Define intrusion-detection rules
- Detect abnormal connection behavior
- Simulate controlled scanning
- Dynamically block suspicious sources
- Measure detection and response time

